# Edu-agent example
def recommend_learning(content):
    return {"recommendation": content[:10]}
