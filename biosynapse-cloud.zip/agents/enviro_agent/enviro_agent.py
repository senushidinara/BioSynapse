# Enviro-agent example
def assess_environment(temp, humidity):
    return {"env_risk": (temp + humidity)/2}
