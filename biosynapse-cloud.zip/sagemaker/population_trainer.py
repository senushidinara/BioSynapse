# SageMaker population trainer example
import random
def train_population(size=3):
    return [{"model_id": i, "fitness": random.random()} for i in range(size)]
