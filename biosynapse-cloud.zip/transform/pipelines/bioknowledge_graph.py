# Transform example
def create_bio_graph(raw_data):
    return [{"gene_id": d["id"], "content": d["text"]} for d in raw_data]
